# Script

[Prologue: Outsider and Inner City #WIP](Script%20ed1906f5cffb4b4abbf59ec27fae52fd/Prologue%20Outsider%20and%20Inner%20City%20#WIP%205ae150c3dbec428783f7e34779cd3f9f.md)