# An Ending #WIP

What is in an ending?

A culmination of efforts and ideas.

An escalation, leading to a climax, and then the denouement. A realization of meaning or revelation of nihilism.

When the chickens are counted and inventory of fruits taken.

It is foreshadowed. It needs to be plausible.

The ending must explore the ideas and choose a side.

It should be human, and show both the rewards and costs of the struggle. It is human-achievable, 

What has a good ending? Which games?

Darkest Dungeon. The narrator is revealed as the villain.

Sekiro. The world changes into one encased in fire, and there is an ultimate showdown between the two best warriors of the key opposing factions. The world is changed.

Classroom of the Elite has several unsatisfying resolutions. Key events occur offscreen, making it impossible to predict.