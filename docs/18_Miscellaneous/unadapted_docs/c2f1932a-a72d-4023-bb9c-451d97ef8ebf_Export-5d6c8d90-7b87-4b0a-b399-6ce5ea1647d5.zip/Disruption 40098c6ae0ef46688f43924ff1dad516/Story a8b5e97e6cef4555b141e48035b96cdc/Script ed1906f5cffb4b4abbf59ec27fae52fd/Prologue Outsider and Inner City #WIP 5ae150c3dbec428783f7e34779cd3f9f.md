# Prologue: Outsider and Inner City #WIP

What does this scene need to accomplish?

- Start establishing Cyrus’ character. He is quick to acclimate, pragmatic.
- Conflict with the Collective.
- Begin establishing the stakes and the conflict.

Darkness.

Then, gradually sparkles of light. They gradually fade.

There are waves of light that emanate from a distant horizon. They are multi-colored.

A female voice says: “Venture forth with blessings, my child.”

Fade to black.

Extreme close-up.

A sun-darkened face. Gray eyes snap open.

Wide shot.

We need a man standing in wide auditorium. 

The walls are light-brown stone, and show hints of ancient, intricate carving, but have started to crumble. There are many rows of dark wood chairs, arranged in circular rings around the deus, on which the man now stands. The chairs get progressively older every few rings.

This strange aging effect is even more evident in the rugs which are much older the further they get from the center, more frayed and washed out.

~~The technological advancement of the auditorium is also confusing. Near the entrances, there are white spheres embedded in walls flanking each door, and many similar spheres litter the grounds throughout the room, shattered in such a way as to suggest they were suspended in the air. However, many torches add light to the chamber.~~