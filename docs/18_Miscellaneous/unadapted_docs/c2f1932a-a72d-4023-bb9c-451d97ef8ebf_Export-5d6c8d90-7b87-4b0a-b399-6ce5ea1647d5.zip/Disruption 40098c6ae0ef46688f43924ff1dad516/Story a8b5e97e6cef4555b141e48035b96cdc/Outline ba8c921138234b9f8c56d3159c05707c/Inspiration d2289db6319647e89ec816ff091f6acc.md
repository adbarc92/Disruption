# Inspiration

- Chrono Trigger
- Lisa the Painful
- Fear and Hunger
- The Darkest Dungeon
- Final Fantasy VII
- Final Fantasy IX
- Final Fantasy X
- Battle Chasers
- Radiant Historia