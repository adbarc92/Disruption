# Lione, the Changeling

[The basic idea is that Lione is a character driven by guilt about her existence. She sees herself as an abomination which has come into the world through the (literal) sacrifice of others, and someone who has had an active negative role in the lives of anyone she’s tried to care for. Of course, this is offset by a deep desire to help people that verges on a compulsion. This is mixed with her desire to undermine, however possible, the Collective.](https://docs.google.com/document/d/1qKl0dzHJO9Dea7xfScyygPJNf8zXj8LO6SSzim0Gh-U/edit)

- -She’s reluctant to show deep affection, though surface-level bubblyness is her M.O.
- -She takes the loss of others extremely personally, and tries to protect herself by pretending not to care. She particularly hates causing harm to the people she loves.
- -She wants nothing more than to take revenge on Phoebe, and to dismantle the collective. In general, she has a serious problem with authority.
- -A lot of this is directed inwards to her “pet” stuffed lion, Nemius. She uses him as a safety blanket and never goes anywhere without him, despite him being from a person she now loathes.