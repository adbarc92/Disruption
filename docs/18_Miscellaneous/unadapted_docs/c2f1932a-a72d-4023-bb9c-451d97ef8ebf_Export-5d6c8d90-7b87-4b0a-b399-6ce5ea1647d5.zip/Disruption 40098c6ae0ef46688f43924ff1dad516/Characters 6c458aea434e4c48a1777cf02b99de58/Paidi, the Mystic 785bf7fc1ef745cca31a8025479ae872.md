# Paidi, the Mystic

[Following their expulsion from Kuklos Anankes, the Order of Pious Sun](../Worldbuilding%20af7a4b31ec684e5e8bd4d886b4f02409/Factions%20432c601a348542f7acd8b40933446729/The%20Order%20of%20Pious%20Sun%20#WIP%2069a06a9c90154df98e9d2658d1c1dabd.md) existed in relative isolation for over a century. As a child, Paidi was exuberant and talkative.

- Paidi has a happy childhood.
- Paidi is a gifted healer.
- Paidi does not get along with other women.
- Paidi is extremely energetic, outgoing, and is popular with men.
- Paidi seeks adventure and excitement, and escapes the confines of the village to explore Kuklos.
- She is spotted by Cyrus (how and why?) and they track her back to their village.
- Now that the secret is out, the Collective wipes out the village to prevent its existence (and the repressiveness of the Forest) from being known.
- Paidi is regretful and turns to alcohol to forget her troubles.