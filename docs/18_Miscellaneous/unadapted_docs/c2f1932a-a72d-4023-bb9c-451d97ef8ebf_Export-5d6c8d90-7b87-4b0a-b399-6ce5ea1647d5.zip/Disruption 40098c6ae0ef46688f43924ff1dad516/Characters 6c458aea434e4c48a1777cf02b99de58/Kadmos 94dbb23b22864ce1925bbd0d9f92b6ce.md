# Kadmos

- Name: Adam (Blood Name Unknown)
    - Epithet: New World’s Firstborn; He Who Knows
    - Features: Hair - White, Eyes - Red
    - Height: 5’11”
    - Weight: 130 lbs. (Decrepit)
    - Age: Unknown (~600)
    - Nationality: Zonian
    - Personality:
        - Overbearing: tends to disallow others’ participation, unless he needs them (for experimentation)
        - Curious: dominated by his desire to acquire new knowledge
        - Ingenious: clever in machinations, both with people and scientific inquiry
        - Psychopathic: only cares about his own interests; would converse with someone while dissecting them
    - Biography:
        - Born during the Disruption, Adam’s existence has ever been one which dominates the attention of others; his early arrival threw his parents’ Collective cell into pure chaos.
        - Reared by parents who were both gifted themselves, Adam has always been the most important person in his own world. For his parents--his father, a renowned Aligner, and his mother, a Glyph of prodigious skill--he was the means by which they would prove their world-view correct
        - Adam grew up in the maelstrom and chaos of the post-Disruption world, and quickly became an asset to the Collective
        - First created ampules, using them to prolong his life