# Gameplay

Inspired by: Gilly (BattleChasers)

Phenotype: Brawler, Tank

Weapon: Fist