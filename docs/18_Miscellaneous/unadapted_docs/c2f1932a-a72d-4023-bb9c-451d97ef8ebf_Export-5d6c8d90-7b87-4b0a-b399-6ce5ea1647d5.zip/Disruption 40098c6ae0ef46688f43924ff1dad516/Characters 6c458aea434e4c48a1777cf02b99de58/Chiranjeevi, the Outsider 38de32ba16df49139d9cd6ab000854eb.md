# Chiranjeevi, the Outsider

- Power sources and design: Parasyte, Yu Yu Hakusho (Elder Toguro)