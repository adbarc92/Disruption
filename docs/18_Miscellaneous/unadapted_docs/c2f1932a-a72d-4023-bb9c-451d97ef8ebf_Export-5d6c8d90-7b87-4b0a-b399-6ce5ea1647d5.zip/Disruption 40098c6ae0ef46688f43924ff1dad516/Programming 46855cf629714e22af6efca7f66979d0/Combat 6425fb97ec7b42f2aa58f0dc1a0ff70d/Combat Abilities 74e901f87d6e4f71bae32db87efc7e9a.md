# Combat Abilities

[v1](Combat%20Abilities%2074e901f87d6e4f71bae32db87efc7e9a/v1%20a1cb86d0c18e43b281954e9a6c66252c.md)

[v2](Combat%20Abilities%2074e901f87d6e4f71bae32db87efc7e9a/v2%2000431ecab0b44ff290a283d51adc5562.md)

[v3](Combat%20Abilities%2074e901f87d6e4f71bae32db87efc7e9a/v3%200366ac9e466d4490a28328907a7ec5fc.md)