# Enemy Ideas

- Sources:
    - Darkest Dungeon
    - Slay the Spire
    - Salt & Sanctuary
    - Remnant: From the Ashes
    - 20 Minutes Till Dawn
    - Demon’s Souls
- Monsters and Beasts
    - Slimes
    - Antonin: a hulking, furry creature with two tails
    - Buff Swineman
    - Mystic Stag: from Wildermyth
    - Divine Bull
    - Grave Worm
        - Source: Divinity 2
    
    ![Untitled](Enemy%20Ideas%2040eebe77dd3a4e60803f3524c69726cd/Untitled.png)
    
    - Gigaxian Ape
    - Giant Rat
    - Two-Tail
    - 
    
    ![Untitled](Enemy%20Ideas%2040eebe77dd3a4e60803f3524c69726cd/Untitled%201.png)
    
    - Threaded Worm: from Darkest Dungeon
    
    ![Untitled](Enemy%20Ideas%2040eebe77dd3a4e60803f3524c69726cd/Untitled%202.png)
    
    - Jaw Beast
    
    ![Untitled](Enemy%20Ideas%2040eebe77dd3a4e60803f3524c69726cd/Untitled%203.png)
    
    - Twin Serpent: Siamese, but I can’t use that word without a Siam
        
        ![Untitled](Enemy%20Ideas%2040eebe77dd3a4e60803f3524c69726cd/Untitled%204.png)
        
    - Reaper Beetle: from Wildermyth
    
    ![Untitled](Enemy%20Ideas%2040eebe77dd3a4e60803f3524c69726cd/Untitled%205.png)
    
- Humans
    - Old Hunter: Bloodborne
    - Common Madman: from Darkest Dungeon
    - Grave Guardian: dressed in a cloth robe like Shrine of Amana tenders
    - Ancient Knight: Sodden knight from Salt & Sanctuary
    - Drunken Fighter
    - Blind Bladesman
- Phantoms
    - Phantasm of the Way
    - Shadow Force
    - Hellbeast: Flamelurker
- Automatons
    - Ruined Golem
    - Battery Serpent
    -