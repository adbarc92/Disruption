# Combat

[Planning (2019-04-26)](Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d/Planning%20(2019-04-26)%20462df2a911b34191b5a7b2c2e88f814e.md)

[Combat Abilities](Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d/Combat%20Abilities%2074e901f87d6e4f71bae32db87efc7e9a.md)

---

[Formulas](Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d/Formulas%2092efb984314142aba7d5a99c643407d6.md)

[Summary](Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d/Summary%20e77c550e188a468ca2759a5310a7e4c8.md)

[Design](Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d/Design%209f38f6a7b01f4bb48685400ff9bca1ce.md)

[](Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d/Untitled%20bc87a886d5684e6ea0b351597badde8d.md)

Timing

Items

[Enemy Ideas](Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d/Enemy%20Ideas%2040eebe77dd3a4e60803f3524c69726cd.md)

[Mock Battle](Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d/Mock%20Battle%20bf905a36c58d46f394f93d11c1bff8f3.md)

Row mechanics: being in the front row means you are more likely to be targeted and will take more damage from physical attacks. This effect decreases as you move back. Magic attacks that are projectiles function the same way. Magic attacks that originate at the target’s location will do the same damage irrespective of row.