# Liz’s Question

- “due to a clerical error” - I don’t understand.
- “a completely new world” what about it is new to him? Everything is new to the viewer, but what makes it completely new for the character?
- “Salvaging equipment and exploration are his lifeblood” these are closely tied to me: it’d be interesting to expand on his desire to resurrect lost things (salvaging materials and discovering a new environment both remind me if repurposing something lost for his own gain, or the gain of others). I’m sleepy but hopefully that makes sense.
- “Despises the government and typically hostile to authority” is this something he could bond with Cyrus over, or does Cyrus’ pragmatic and focused nature give him an appreciation for authority figures?
- “drinks in equal proportion”, why does she drink? Why does she flirt when she drinks? Did she lose someone she loves and wants to feel that love again? Is she deceitful, or does she want to prove that love isn’t real and it’s all a game?
- “Generally hot-tempered and naive.” I can almost see her naïveté as a result of her not being in society, but I would imagine she’s super withdrawn and wouldn’t be so outgoing as to make those kinds of social blunders.
- “a reality-hopping man unchained from reality and thus with no place in any world” what? So this is a multi-dimensional place? How did he become unchained? Does he was any control over this? “Hides cynical perspectives about the shortcomings of humans.” is he not human?
- “unshackled by the contempt for Kuklos residents common to his people.” Unburdened by what has been
- “organized Cyrus’ team in the past” Is she also confused by how she got here, like Cyrus? How long has she been here?
- “Unconsciously longs for a man to put her in her place.” What place does she want to be put in? She doesn’t want to be a leader?
- “Has long since lost hope in their cause but sees no other option.” No other option than to join them? Why?