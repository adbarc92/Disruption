# Metaphor ReFantasio

- Meta frame narrative about the real world
- Music is the first magic
-