# Character Inspiration #WIP

- Obliteration (Reckoners)