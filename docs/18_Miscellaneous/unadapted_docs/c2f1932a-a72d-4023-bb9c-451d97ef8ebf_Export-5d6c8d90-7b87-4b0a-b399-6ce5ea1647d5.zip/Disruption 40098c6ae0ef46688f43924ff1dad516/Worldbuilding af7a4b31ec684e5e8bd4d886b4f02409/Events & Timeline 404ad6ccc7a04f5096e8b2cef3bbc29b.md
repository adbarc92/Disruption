# Events & Timeline

- Beginning of the New Age (Age of Wisdom)
- -200k: Tool Revolution
- -50k: Settling of Kyanos
- -1k: Discovery of Runes
- 0: The Enlightenment

[The Disruption #WIP](Events%20&%20Timeline%20404ad6ccc7a04f5096e8b2cef3bbc29b/The%20Disruption%20#WIP%201ca3b38f76bb4412a094ce216c73bff8.md)