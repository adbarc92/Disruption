# Reality Layers

[Brainstorm](Reality%20Layers%20d96b434e7ab1422f993560dc1cd4a554/Brainstorm%202edda29982e840539c52733709c12fef.md)

There are five layers of reality, with three being primary and two being interstitial.

The Realm of Light, symbolized by a burning moon (flame of light and Mirror-Flower-Water-Moon conjunction)

- The primary realm from which all things extend; occupied solely by the Monad.

The Realm of Waves, symbolized by a tempest

- The Realm of Pure Emanations, where all secondary Aeons reside, including the Second and the Son.

The Realm of Images, symbolized by a river

- This is where the Avatars dwell, as they are images of the human virtue.
- Names

The Realm of Echoes, symbolized by concentric circles.

- This can be brought unto the world by use of a sacred relic, The Image of Shadow, a smooth, black stone with undulating lines. Sometimes appears as an eye. In the promised time, the lines align in the runes “Chaos” and “Eternity”.
- Dwelling in the Realm of Echoes tends to overwhelm and subsume the mind. Some turn into purely cognitive entities, some are reduced to a purely bestial nature.

The Realm of Shadow, symbolized by a beast