# Ascension #WIP

[Brainstorm](Ascension%20#WIP%202997ea47e69e451cba3f000ced477fa3/Brainstorm%20567d12675900497fb4d521c286ce8676.md)

There are a few different ways that a human can rise to become an Avatar.

The primary way is Succession, wherein an Avatar chooses a worthy human, who can choose to accept or reject the offer. If they reject, then they are passed over, returning to their previous life, and the Avatar can choose whether or not to try again. If they accept then the power is passed down. The previous Avatar passes into the Realm of Waves, and the new Avatar rises to the Realm of Images. This can be done at any time.

The secondary way is Rebellion (Deposition), wherein one Conduit gathers a sufficient amount of Exousia (either from a land or group of people).