# Sanderson’s Shards

- Preservation
- Ruin
- Dominion
- Devotion
- Autonomy
- Odium
- Honor
- Cultivation