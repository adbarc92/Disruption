# Greek Gods

- Ares: War, Anger, Rage
- Athena: Wisdom, Sophia
-