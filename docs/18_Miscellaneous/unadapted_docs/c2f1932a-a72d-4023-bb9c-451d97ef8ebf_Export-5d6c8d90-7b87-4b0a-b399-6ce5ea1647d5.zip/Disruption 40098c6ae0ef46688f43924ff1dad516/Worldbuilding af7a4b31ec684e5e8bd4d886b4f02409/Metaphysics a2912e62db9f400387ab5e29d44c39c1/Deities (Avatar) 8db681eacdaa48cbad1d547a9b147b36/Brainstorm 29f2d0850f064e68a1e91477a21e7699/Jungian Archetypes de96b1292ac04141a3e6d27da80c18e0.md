# Jungian Archetypes

![Untitled](Jungian%20Archetypes%20de96b1292ac04141a3e6d27da80c18e0/Untitled.png)

![Untitled](Jungian%20Archetypes%20de96b1292ac04141a3e6d27da80c18e0/Untitled%201.png)