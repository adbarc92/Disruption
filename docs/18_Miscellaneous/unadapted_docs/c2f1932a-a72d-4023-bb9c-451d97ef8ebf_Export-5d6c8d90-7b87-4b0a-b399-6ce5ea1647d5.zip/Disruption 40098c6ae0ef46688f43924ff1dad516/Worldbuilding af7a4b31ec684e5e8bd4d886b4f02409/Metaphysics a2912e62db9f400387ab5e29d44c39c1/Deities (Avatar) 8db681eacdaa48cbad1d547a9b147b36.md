# Deities (Avatar)

[Cosmogony](Deities%20(Avatar)%208db681eacdaa48cbad1d547a9b147b36/Cosmogony%20f8494c2f2b39402b897242189199456c.md)

[Brainstorm](Deities%20(Avatar)%208db681eacdaa48cbad1d547a9b147b36/Brainstorm%2029f2d0850f064e68a1e91477a21e7699.md)

[Ascension #WIP](Deities%20(Avatar)%208db681eacdaa48cbad1d547a9b147b36/Ascension%20#WIP%202997ea47e69e451cba3f000ced477fa3.md)

[Sanderson’s Shards](Deities%20(Avatar)%208db681eacdaa48cbad1d547a9b147b36/Sanderson%E2%80%99s%20Shards%2010354f18b5c8806ab024eef9f6fe1ef3.md)

[Gnostic Aeons](Deities%20(Avatar)%208db681eacdaa48cbad1d547a9b147b36/Gnostic%20Aeons%2051b380efb79a44dbaa652a1e4463cb57.md)