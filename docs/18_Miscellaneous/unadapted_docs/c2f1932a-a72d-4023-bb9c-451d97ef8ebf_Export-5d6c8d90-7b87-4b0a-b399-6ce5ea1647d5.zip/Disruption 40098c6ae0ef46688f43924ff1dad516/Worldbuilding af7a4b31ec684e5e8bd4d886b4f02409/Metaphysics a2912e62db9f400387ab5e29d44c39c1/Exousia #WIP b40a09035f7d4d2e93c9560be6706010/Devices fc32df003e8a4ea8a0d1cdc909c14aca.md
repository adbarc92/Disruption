# Devices

Touchstone: Danger Beast Items (Akame ga Kill)

- Weapons [[1](https://list25.com/25-legendary-mythical-weapons-which-shaped-history/)] [[2](https://en.wikipedia.org/wiki/List_of_magical_weapons)] [[3](https://en.wikipedia.org/wiki/List_of_mythological_objects)] [[4](https://www.wowhead.com/obtaining-legacy-legendary-items-guide)] [[5](https://bloodborne.wiki.fextralife.com/Lore+glossary)]
    - Asura (Assurance): a blade forged to battle monsters consumed by magic
        - Appearance: a thin, black blade which, when drawn, appears to be shrouded in a veil which distorts the air around it in a magic-consuming vortex; the blade’s coloration is darkest at the tip and lightest at the hilt;
        - History:
            - Forged in an eastern city-state by a madman who was driven to steal the powers of magicians
            - The blade is corrupted by his desires
    - Abe (Aberration/Ability/)
- Objects
    - Skin of the Chosen: carved from the hide of a legendary beast, this skin shapes itself to those
    - Altesh, The Reaver:
    - Wreth, The Luce:
    - Cruin, The Wave:
    - Ioril, The Silence
    - Rukar, The Listener
    - Shannis, the Shooter
    - Lilsanis, The Ocean
    - Urithil, the Serpent
    - Kuth, the Slayer
    - Cirith, the Kite