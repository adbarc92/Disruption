# The Unknown

The region beyond Kuklos in all directions. Layered by the ripple effect of the Disruption.

- ~~NOTE TO SELF: This needs a governing principle or metaphor that orders the layering. Development of mankind? Grief? Aeonic correspondence? Should this be metaphorical, metaphysical, or both?~~
- Governed by the principle of excessive growth (Aeon currently unknown).

[Brainstorm](The%20Unknown%20ebd6d418d13a45d0a76ec6f6c7852eda/Brainstorm%20ec61c1fc107e473f97b697a7b184c56a.md)

[Brainstorm 2](The%20Unknown%20ebd6d418d13a45d0a76ec6f6c7852eda/Brainstorm%202%20c2c6f9cb072a4929920823f5f83b1aa3.md)

1. The Rainforest or Jungle (music: flutes and violin)
    1. Points of interest
        1. Defector Settlements (Adventurers)
        2. Beast Dens
        3. Collective Bases
        4. Traps
        5. Small rivers
        6. Churches to Sophia
        7. Cathedrals of Ruin
    2. Creatures
        1. Parasite-riddled corpse
2. The Marshes or Swamp
    1. The Village of Monks
3. The Infinite River (piano and xylophone)
    1. Corpse Island
4. The Stonefield (drums and choir); petrified forest
    1. The Quarries
    2. The Craters
5. The Mountains
    1. Noble Retreat Grounds
    2. Vanarist Proving Ground
6. The Valleys
    1. Vanar
        1. The Seed
        2. The Lumber Yard
        3. The Forges
7. The Skeletal Tree Yard (Sitar and zuma flute)
    1. Graveyard
8. The Desert of Mist