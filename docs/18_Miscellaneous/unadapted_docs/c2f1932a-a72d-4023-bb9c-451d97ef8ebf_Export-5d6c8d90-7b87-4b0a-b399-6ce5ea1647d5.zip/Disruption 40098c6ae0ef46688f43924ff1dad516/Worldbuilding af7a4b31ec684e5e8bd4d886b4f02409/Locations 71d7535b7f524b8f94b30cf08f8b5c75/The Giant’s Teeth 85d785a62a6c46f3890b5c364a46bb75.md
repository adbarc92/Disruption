# The Giant’s Teeth

A large mountain range northwest of Kyanos. The source of the river that led to the creation of Kyanos.