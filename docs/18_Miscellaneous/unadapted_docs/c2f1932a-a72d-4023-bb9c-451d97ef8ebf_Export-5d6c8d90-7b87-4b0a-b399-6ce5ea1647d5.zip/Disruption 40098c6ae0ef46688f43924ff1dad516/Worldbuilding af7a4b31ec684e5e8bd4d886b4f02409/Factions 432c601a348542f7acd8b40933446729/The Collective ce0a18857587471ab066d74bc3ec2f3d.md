# The Collective

A conglomerate of political leaders and prominent social figures seeking to become Principalities.

 Analogous to the real-world Illuminati. If the Collection wanted to escape the Disruption, they possess the knowledge and power to do so. They intend to keep everyone within its confines as the despair and concession of the populace are necessary conditions of the Ascension ceremony.

- The Augmented: A group of humans who have taken Devices into their bodies to become biomechanical. Only special agents of the Collective have the technology necessary to make this work, as most Devices were developed to work with Pre-Zonian Exousia.
- The Legacy: a splinter group of reformed Collective agents.
- Clothing: Victorian, black, etc.

**Collective Strike Force**

Luftwaffe War Establishment (Kriegsstärkenachweisung) 8121(L) dated 1.5.44 gives the following organization for a rifle platoon in a Fallshirmjägerkompanie:

Zugführer (Platoon Leader) Lt,

Zugtrupp (Platoon HQ section)

1 Zugtruppführer (Sec Ldr)

3 Melder (Messenger)

1 Waffenwart (Armorer)

3 Squads, including in total (for all 3 squads)

3 Gruppenführer (Squad Leader)

3 Stellvertretende Gruppenführer (Deputy Squad Leader)

12 Schützen (Riflemen)

12 MG-Schützen (Machinegunners and assistants)

2 Drivers for 3-ton trucks

All personnel except the Platoon Leader (Lieutenant) were NCOs. NOTE: All enlisted personnel in Luftwaffen Parachute units were NCOs.

The Platoon was armed as follows (the War Establishment does not assign weapons to individuals)

16 Rifles (incl. 3 with sniper telescopes)

13 Pistols

9 Submachineguns

3 Grenade pistols ("Kampfpistole" these were modified flare guns that could shoot small grenades)

6 Rifle grenade adapters

6 Machineguns.

As a comparison, a contemporary Army rifle platoon of the period had 33 personnel and the following weapons:

22 Rifles

5 Pistols

7 Submachineguns

4 Machineguns

Regards,

Paul Barnett

from a military history sight. the collective strike force would be similar to a fallshrimjager group in that they'd be mobile but well trained and well armed.

basically you would switch out some of the MG operators for ulta-heavy flamer units andor mechs. the 3ton trucks would be strike hovercraft

- -----------

so the way i see it you'd have something like 1 high-officer commanding 3 squads with EACH: squad leaders/deputy leaders (they'd also each have a messenger using radio-adjacent comms, if those work in the disruption), 12 regulars equipped with adaptive armor and mid-caliber ballistic weapons (gunpowder SMGS or assault rifles as we've discussed the Collective having), 4 ultra-heavy infantry (mechs--these would probably be the flamers as they could carry a lot of fuel) with probably 2 dedicated engineers to service them on the field, 4 MG/Ampule Anti-material/explosives crews (2 people each for carrying and operating the heavy weapons), and 2 dedicated scouts with cloaking tech and some kind of quiet weapon.

The flight crew(s) would be a pilot and co-pilot per ship, and maybe a gunner if you think the dropship(s) would be armed

a good aircraft to look at for that would be the Osprey

- -----

I'd say you want either one or three dropships, but it depends on how big they are.

One dropship big enough to carry an entire platoon would be more like the size of a large passenger aircraft (e.g. a C130 Hercules --HUGE), while one big enough to carry a single squad would be the size of a large helecopter

you could also say the operation is a surgical event, and so only a single limited squad was sent--but I think a display of overwhelming force is good for the story.