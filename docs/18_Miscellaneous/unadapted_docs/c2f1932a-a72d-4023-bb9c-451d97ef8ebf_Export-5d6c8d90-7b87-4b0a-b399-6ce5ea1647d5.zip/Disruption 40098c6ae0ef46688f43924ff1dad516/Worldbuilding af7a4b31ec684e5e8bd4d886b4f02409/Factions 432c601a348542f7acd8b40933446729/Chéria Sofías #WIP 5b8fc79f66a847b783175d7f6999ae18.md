# Chéria Sofías #WIP

Greek: Χέρια Σοφίας (lit. “Hands of Wisdom”)

The Yomenites

Originally, the name for the group now called the “Vanar.”

The Aiel, the Fremen

Siopí (Greek: “Silence”)

Sofós (Greek: “Wise”)

Originally one of Sophia’s tribes that wandered the desert. Gradually, they learned to adapt to the desert, and treated water as gold. They battled many other tribes, wore the skins of animals, and went on pilgrimages to the mountains in the West, the Seas to the North, and the Wetlands to the East.