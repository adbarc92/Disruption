# Metaphysics

[Deities (Avatar)](Metaphysics%20a2912e62db9f400387ab5e29d44c39c1/Deities%20(Avatar)%208db681eacdaa48cbad1d547a9b147b36.md)

[Bubbles](Metaphysics%20a2912e62db9f400387ab5e29d44c39c1/Bubbles%209722e349b58c4016a6c57f299d47fdda.md)

[Latent Chaos](Metaphysics%20a2912e62db9f400387ab5e29d44c39c1/Latent%20Chaos%20bf7517f51d104c73a087028feb2d51be.md)

[Reality Layers](Metaphysics%20a2912e62db9f400387ab5e29d44c39c1/Reality%20Layers%20d96b434e7ab1422f993560dc1cd4a554.md)

[Connection](Metaphysics%20a2912e62db9f400387ab5e29d44c39c1/Connection%2065488a5ff3d347b2b96c827f023207ec.md)

[Exousia #WIP](Metaphysics%20a2912e62db9f400387ab5e29d44c39c1/Exousia%20#WIP%20b40a09035f7d4d2e93c9560be6706010.md)

Why would the convergence of layers result in a forest? Shouldn’t it be an onset of images? Or the realm of the dead?

What is the meaning of magic and ampoules?

- Investiture
- Golden Bough

What happens after death?

Race realism?

Who are the Avatars? Which traits?

Why does Exousia turn people into beasts?

How can Exousia be channeled?
What are the responsibilities of an Avatar? What can they actually do? Why would someone want to become one?

How does one break the Ascension shell?