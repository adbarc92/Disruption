# The Disruption Problem

The problem is thus:

1. People have exousia.
2. Land has exousia.
3. The land will realign itself over time to match the exousia of the residents.
4. The Disruption changed the Exousia of the land nearby.
5. Devices require a piece of the exousia specific to the land.
6. Devices require runes specific to the land.
7.