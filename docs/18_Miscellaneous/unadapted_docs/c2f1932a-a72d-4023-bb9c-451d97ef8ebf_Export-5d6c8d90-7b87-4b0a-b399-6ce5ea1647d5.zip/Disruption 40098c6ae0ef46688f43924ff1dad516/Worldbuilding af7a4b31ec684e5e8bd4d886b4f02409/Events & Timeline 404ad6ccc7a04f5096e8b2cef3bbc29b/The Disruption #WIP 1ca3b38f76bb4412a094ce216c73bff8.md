# The Disruption #WIP

Also called “The Cataclysm”, in-world.

An event that radically alters Kyanos’ ecology, exousia, and kills most of its population. The inciting event of the game. Brought about by the Collective for the purpose of bringing about a series of Ascensions.

- Actually a combination of events: one that changed the land and another that froze time at the very center of the city, intended to preserve the Collective members there for their eventual Ascension.
- All is forest? Everything is a variation on that theme?
- How does one end the Disruption? Kill what sustains it. What is sustaining it? Devices? Collective forces? Beasts that originate from the intruding God?

[The Disruption Problem](The%20Disruption%20#WIP%201ca3b38f76bb4412a094ce216c73bff8/The%20Disruption%20Problem%204336fe87dc6f40dba4a7ebba885a2b97.md)