# Characters

**Party Members**

[Cyrus, the Seeker](Characters%206c458aea434e4c48a1777cf02b99de58/Cyrus,%20the%20Seeker%20cd3bdea2c59c420ca0e474dc71320fe0.md)

[Vaughn, the Hawk](Characters%206c458aea434e4c48a1777cf02b99de58/Vaughn,%20the%20Hawk%200e5842041f0045b68e524d487e8408f3.md)

[Phaidros, Second Gnosis](Characters%206c458aea434e4c48a1777cf02b99de58/Phaidros,%20Second%20Gnosis%202cc68260550e46b5a9ca7e04e73007be.md)

[Paidi, the Mystic](Characters%206c458aea434e4c48a1777cf02b99de58/Paidi,%20the%20Mystic%20785bf7fc1ef745cca31a8025479ae872.md)

[Lione, the Changeling](Characters%206c458aea434e4c48a1777cf02b99de58/Lione,%20the%20Changeling%20f19bb71a6eb74a4693018d916be0a2b2.md)

[Euphen, the Wanderer](Characters%206c458aea434e4c48a1777cf02b99de58/Euphen,%20the%20Wanderer%20feb435ac4a914d89897032df7aad3288.md)

[Chiranjeevi, the Outsider](Characters%206c458aea434e4c48a1777cf02b99de58/Chiranjeevi,%20the%20Outsider%2038de32ba16df49139d9cd6ab000854eb.md)

[Sophia, the Assassin](Characters%206c458aea434e4c48a1777cf02b99de58/Sophia,%20the%20Assassin%2083177f0c866148048e0c541b3cb90ef5.md)

[Adam, the Supreme](Characters%206c458aea434e4c48a1777cf02b99de58/Adam,%20the%20Supreme%2072b863fd3cb8474e81009a73afd5e86e.md)

[Party Dynamics](Characters%206c458aea434e4c48a1777cf02b99de58/Party%20Dynamics%204a834412d34b4df78e25ca570ea2215b.md)

**Important Figures**

[Names](Characters%206c458aea434e4c48a1777cf02b99de58/Names%2010154f18b5c88092ab4cd7857dee755e.md)

- The Master of Those Who Know: a mysterious figure who visited Kyanos long ago and imparted sacred knowledge of the Ascension ceremony unto the Elders of the city.
- Dominus: the leader of the Collective, sealed near Cyrus closest to the egg.
- Leontios: a crime boss around Kuklos. Handles some executions and smuggling.

[Kadmos](Characters%206c458aea434e4c48a1777cf02b99de58/Kadmos%2094dbb23b22864ce1925bbd0d9f92b6ce.md)