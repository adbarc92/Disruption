# Worldbuilding

[https://youtu.be/noZbM2Hd9rA?si=4dobIB9je1TQETqy](https://youtu.be/noZbM2Hd9rA?si=4dobIB9je1TQETqy)

[Metaphysics](Worldbuilding%20af7a4b31ec684e5e8bd4d886b4f02409/Metaphysics%20a2912e62db9f400387ab5e29d44c39c1.md)

[Locations](Worldbuilding%20af7a4b31ec684e5e8bd4d886b4f02409/Locations%2071d7535b7f524b8f94b30cf08f8b5c75.md)

[Factions](Worldbuilding%20af7a4b31ec684e5e8bd4d886b4f02409/Factions%20432c601a348542f7acd8b40933446729.md)

[Events & Timeline](Worldbuilding%20af7a4b31ec684e5e8bd4d886b4f02409/Events%20&%20Timeline%20404ad6ccc7a04f5096e8b2cef3bbc29b.md)

Who writes the item descriptions?

[Creatures](Worldbuilding%20af7a4b31ec684e5e8bd4d886b4f02409/Creatures%2013154f18b5c88080abe5d8c80cce8b7a.md)

- New things we need:
    - Gestrals from E33
    - A discernable, somewhat-objectively identifiable pattern for the forest zones.
        - The Inverted Seas.