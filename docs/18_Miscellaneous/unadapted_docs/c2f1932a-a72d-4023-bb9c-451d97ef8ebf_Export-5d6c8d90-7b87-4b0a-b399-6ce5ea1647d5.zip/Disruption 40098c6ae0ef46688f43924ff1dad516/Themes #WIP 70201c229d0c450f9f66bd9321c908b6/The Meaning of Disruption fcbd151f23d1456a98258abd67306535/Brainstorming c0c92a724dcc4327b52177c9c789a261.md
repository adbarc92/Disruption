# Brainstorming

Main categories

- Monotheistic
- Polythestic
- Pantheistic
- Atheistic

Tarot symbolism

- Polytheistic zodiac system?