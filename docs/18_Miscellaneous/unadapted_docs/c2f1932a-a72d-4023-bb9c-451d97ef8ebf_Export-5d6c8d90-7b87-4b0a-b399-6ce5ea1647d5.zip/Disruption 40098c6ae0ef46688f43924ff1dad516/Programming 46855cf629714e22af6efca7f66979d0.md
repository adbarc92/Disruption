# Programming

[Combat](Programming%2046855cf629714e22af6efca7f66979d0/Combat%206425fb97ec7b42f2aa58f0dc1a0ff70d.md)

[Status Effects](Programming%2046855cf629714e22af6efca7f66979d0/Status%20Effects%20611978afef7a4b31accfef8eac1150ae.md)

Core Stats:

- Constitution
- Strength
- Dexterity
- Resonance
- Agility

Derived Combat Stats:

-