# Gameplay Mechanics

Crafting

Exploration

Base building

Speed-up button, hold to fast-forward, cutscene skipping

Lootable chest

Breakables

Sprint

Property adoption, extension: association leads to addition of new aspects as innate

Draw Weapon: changes world into a hostile state, where civilians will run and guards will try to attack. The player can strike in this state, and will initiate a battle with advantage.

New Game Plus: this should be different from the previous 

[Brainstorm](Gameplay%20Mechanics%20a952c69cac66496fba2b50ef6a86c2c7/Brainstorm%2020db39d4f7bc43148841a19ac8b4ac1a.md)